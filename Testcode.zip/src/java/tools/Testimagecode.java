package tools;
 
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
/**
 * Servlet implementation class Testimagecode
 */
@WebServlet("/Testimagecode")
public class Testimagecode extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Testimagecode() {
        super();
        // TODO Auto-generated constructor stub
    }
 
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		//获取request中的，也就是输入的imagecode，也就是那个input标签的内容
		String imagecode=request.getParameter("imagecode");
		//获取存入session的码
		String imagecode1=(String)request.getSession().getAttribute("imagecode");
		//获取之后得删除，防止下次验证错误
		request.getSession().removeAttribute("imagecode");
		//这两句话是用来检测是否自己的代码有错误，看是jsp写错了，还是验证码写错了
		System.out.println(imagecode);
		System.out.println(imagecode1);
		if(!(imagecode!=null&&imagecode1.equals(imagecode))) {
			//回复错误信息并转发到原来的页面
			request.setAttribute("imagecodemsg", "code error");
			request.getRequestDispatcher("/JSP/login.jsp").forward(request, response);
			return;
		}
		//转发到成功的页面
		request.getRequestDispatcher("/JSP/success.jsp").forward(request, response);
	}
 
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
 
}