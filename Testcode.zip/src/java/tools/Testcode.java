package tools;
 
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;
 
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
/**
 * Servlet implementation class Testcode
 */
@WebServlet("/Testcode")
public class Testcode extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Testcode() {
        super();
        // TODO Auto-generated constructor stub
    }
 
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int width=120;
		int height=40;
		//获取画布
		BufferedImage image=new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
		//获取画笔
		Graphics2D g=(Graphics2D) image.getGraphics();
		//设置实心矩形的颜色
		g.setColor(Color.GRAY);
		//画一个实心的矩形,将画布覆盖
		g.fillRect(0, 0,width,height);
		//设置矩形边框的颜色
		g.setColor(Color.BLUE);
		//画出矩形的边框，由于边框也是有像素的，所以是宽度高度分别减去一
		g.drawRect(0, 0, width-1, height-1);
		//设置验证码中的数据
		String words="QWERTYUIOPASDFGHJKLZXCVBNM1234567890";
		//获取随机这个对象使得可以在String中随机获得字母
		Random random=new Random();
		//设置验证码中的字体颜色
		g.setColor(Color.yellow);
		//改变字体
		g.setFont(new Font("宋体",Font.BOLD,35));
		//x和y是字母在画布中的相对位置，x是不断变得，y是不变的
		int x=20;
		int y=30;
		String msg="";
		for(int i=0;i<4;i++) {
			//在words的长度范围内获取一个随机的索引值
			int index=random.nextInt(words.length());
			//通过那个索引值找到相应的字母
			char ch=words.charAt(index);
			//获取正负30的角度
			int jiaodu=random.nextInt(60)-30;
			double hudu=jiaodu*Math.PI/180;
			g.rotate(hudu,x,y);
			//把字母画在画布上
			g.drawString(ch+"", x, y);
			//把每次旋转的再旋转回来
			g.rotate(-hudu,x,y);
			//每次向右移动20像素
			x+=20;
			msg+=ch;
		}
		//将内容存到session域中
		request.getSession().setAttribute("imagecode", msg);
		//画干扰线
		int x1;int x2;int y1;int y2;
		for(int i=1;i<4;i++) {
			x1=random.nextInt(width);
			x2=random.nextInt(width);
			y1=random.nextInt(height);
			y2=random.nextInt(height);
			g.drawLine(x1, y1, x2, y2);
		}
		//将画的内容以图片的形式输出
		ImageIO.write(image, "jpg", response.getOutputStream());
	}
 
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
 
}